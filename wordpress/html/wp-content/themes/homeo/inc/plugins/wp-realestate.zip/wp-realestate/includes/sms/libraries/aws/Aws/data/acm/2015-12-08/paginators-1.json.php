<?php
// This file was auto-generated from sdk-root/src/data/acm/2015-12-08/paginators-1.json
return [ 'pagination' => [ 'ListCertificates' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxItems', 'output_token' => 'NextToken', 'result_key' => 'CertificateSummaryList', ], ],];
