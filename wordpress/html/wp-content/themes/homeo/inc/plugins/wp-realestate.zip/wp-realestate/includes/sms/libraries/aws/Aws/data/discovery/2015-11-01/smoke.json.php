<?php
// This file was auto-generated from sdk-root/src/data/discovery/2015-11-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeAgents', 'input' => [], 'errorExpectedFromService' => false, ], ],];
